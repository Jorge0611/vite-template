import create from "zustand";

export type _ItemStore = {
  items: {
    id: number;
    name: string;
  }[];
  addItem: (item: string) => void;
  removeItem: (id: number) => void;
};

export const useItemsStore = create<_ItemStore>((set) => ({
  items: [{ id: 1, name: "Bear" }],
  addItem: (item) =>
    set((state) => ({
      items: [
        ...state.items,
        { id: (state.items.at(-1)?.id ?? 0) + 1, name: item },
      ],
    })),
  removeItem: (item) =>
    set((state) => ({ items: state.items.filter((i) => i.id !== item) })),
}));
