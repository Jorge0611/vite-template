import { FC, useState } from "react";
import { useItemsStore } from "@/stores/items";

export default function Items(): ReturnType<FC> {
  const { items, addItem, removeItem } = useItemsStore();
  const [item, setItem] = useState<string>("");

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    addItem(item);
    setItem("");
  };

  return (
    <div className="flex h-screen w-full flex-col justify-center">
      <header>
        <h1 className="font-bold">Items</h1>
        <p>Items page</p>
      </header>
      <main className="mt-8 flex flex-col items-center justify-center ">
        <div className="flex w-full flex-col space-y-2">
          {items.map((item, index) => (
            <div
              key={index}
              className="flex w-full items-center justify-between border-2 border-sky-700 p-3"
            >
              <span className="mr-12 font-semibold uppercase">
                {item.id + " - " + item.name}
              </span>
              <button
                className="btn"
                onClick={() => {
                  removeItem(item.id);
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </div>
        <form
          className="mt-4 flex w-1/2 flex-row items-center space-x-2"
          onSubmit={handleSubmit}
        >
          <input
            className="input w-full"
            type="text"
            name="item"
            id="item"
            value={item}
            required
            onChange={(e) => setItem(e.target.value)}
          />
          <button type="submit" className="btn btn-primary w-1/4">
            Add bear
          </button>
        </form>
      </main>
    </div>
  );
}
